#pragma once
#include <cstdint>

namespace Sort {

	void sort_buff(uint64_t N, long LENGTH, uint8_t* buff);

}

